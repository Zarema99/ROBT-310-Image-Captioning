#ROBT310: Project - README
#Cartoonization of Image Parts
#Aibek Abilgazym, ID:201895901
#Karina Burunchina, ID:201545437
#Zarema Balgabekova, ID:201783270

#INSTALLATION

First of all, go to https://www.python.org/downloads/ and download the latest release of the Python,
suitable for your system.
When installing, make sure to check the "Add Python to PATH" option.
Now, press 'Win+R', type 'cmd' and hit Enter.
Now, run the following commands in order:

pip install numpy scipy
pip install opencv-contrib-python
pip3 install torch==1.8.1+cu102 torchvision==0.9.1+cu102 torchaudio===0.8.1 -f https://download.pytorch.org/whl/torch_stable.html

Now, extract the contents of the archive to a folder.

You can now start using the programs.

#RUNNING

#GAN Cartoonizer - "gan.py"
This part of the manual includes instructions on how to start the GAN Cartoonizer.

1) Open the Command Line and type cd <Location of your project folder>
2) Type 'py gan.py' and press Enter
3) The program is going to start and will tell if it uses CPU or GPU for this program 
and will print the name of the GPU in case of latter
4) Once the program has printed "Type 0 for webcam, type 1 to use a videofile", select whether you would like to
record a video from the webcam and use it for cartoonization or use an already existing videos. 
Type 0 or 1 respectively.
5)If you chose to read from videofile, you must type the name of the file in project folder, like "test.mp4".
6)Next, please enter 0 or 1 if you would like just to cartoonize only faces on an image, or the whole area of the video.
7) If a webcam was chosen, the window will show up that makes a recording of your webcam. To stop the recording,
press on the window and push the "Esc" button. The video will be saved as "MyOutputVid.avi" in project folder and
the algorithm will move forward.
8)Now, the "Processing" message should appear, indicating that the video is being processed.
9) Once the video has been processed, a new videofile named "result.avi" will appear in project folder with results of cartoonization.
10) You can choose between different styles: "Hayao", "Paprika by changing the 'style' variable in the source code.
#Real-time cartoonizer - "filter.py"
This part of the manual includes instructions on how to start the simple real-time cartoonizer.

1) Open the Command Line and type cd <Location of your project folder>
2) Type 'py simple.py' and press Enter.
3) The program will create a new window with real-time cartoonization result from your webcam. The algorithm
automatically tracks the face and applies the cartoonization only to that part of the image.
4) The video of the tracking is recorded and saved as "MyOutputVid.avi" in project folder.

#Object extraction and cartoonization - "filter.py"
1)To apply object extraction use function object_extr(img), where img is your input image. 
2)The algorithm works properly on the images with one-color background. 
3)If the output image does not defined object properly, try to change canny_low and canny_high parameters.