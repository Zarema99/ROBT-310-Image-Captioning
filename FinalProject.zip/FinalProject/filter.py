#ROBT310: Project - Cartoonization of Image Parts
#Real-time cartoonizer
#Aibek Abilgazym, ID:201895901
#Karina Burunchina, ID:201545437
#Zarema Balgabekova, ID:201783270

import cv2
import numpy as np
def color_quantization(img, k):
# Defining input data for clustering
  data = np.float32(img).reshape((-1, 3))
# Defining criteria
  criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1.0)
# Applying cv2.kmeans function
  ret, label, center = cv2.kmeans(data, k, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
  center = np.uint8(center)
  result = center[label.flatten()]
  result = result.reshape(img.shape)
  return result

face_cascade = cv2.CascadeClassifier(
    './haar/haarcascade_frontalface_default.xml')   

camera = cv2.VideoCapture(0)
fps = 24
size = (int(camera.get(cv2.CAP_PROP_FRAME_WIDTH)),
        int(camera.get(cv2.CAP_PROP_FRAME_HEIGHT)))
videoWriter = cv2.VideoWriter(
    'MyOutputVid2.avi', cv2.VideoWriter_fourcc('M','J','P','G'), fps, size)
while (cv2.waitKey(1) == -1):
    success, frame = camera.read()
    if success:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5, minSize=(60, 60))#check for faces on image
        flag = 0
        for (x, y, w, h) in faces:
            test = frame[y:y+h, x:x+w]
            
            gray = cv2.cvtColor(test, cv2.COLOR_BGR2GRAY)
            gray_1 = cv2.medianBlur(gray, 5)
            edges = cv2.adaptiveThreshold(gray_1, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 9, 5)
            color = cv2.bilateralFilter(test, d=9, sigmaColor=200,sigmaSpace=200)
            cartoon = cv2.bitwise_and(color, color, mask=edges)
            scale_percent = 40 # percent of original size
            width1 = test.shape[1]
            height1 = test.shape[0]
            width = int(width1 * scale_percent / 100)
            height = int(height1 * scale_percent / 100)
            dim = (width, height)
            resized = cv2.resize(cartoon, dim)
            img_1 = color_quantization(resized, 48)
            dim2 = (width1, height1)
            test = cv2.resize(img_1, dim2)
            flag = 1
        if flag == 1:
            frame[y:y+h, x:x+w] = test
        videoWriter.write(frame)
        cv2.imshow('Face Cartoonizer', frame)
        flag = 0
        
