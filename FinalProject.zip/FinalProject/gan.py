#ROBT310: Project - Cartoonization of Image Parts
#GAN Cartoonization
#Aibek Abilgazym, ID:201895901
#Karina Burunchina, ID:201545437
#Zarema Balgabekova, ID:201783270

import torch
import torch.nn as nn
import torch.nn.functional as F
from network.Transformer import Transformer
import os.path
import numpy as np
from PIL import Image
import torchvision.transforms as transforms
from torch.autograd import Variable
import cv2
import time
model = Transformer()
face_cascade = cv2.CascadeClassifier(
    './haar/haarcascade_frontalface_default.xml')
style = 'Paprika'
model.load_state_dict(torch.load(style + '_net_G_float.pth'))
model.eval()
gpu = 0
if gpu > -1:
  print('GPU mode')
  model.cuda()
  print(torch. cuda. get_device_name(torch. cuda. current_device()))
else:
  print('CPU mode')
  model.float()
  
  
  
def test_GAN (img): #load_size ?

  img = np.asarray(img)
  # RGB -> BGR
  img = img[:, :, [2, 1, 0]]
  img = transforms.ToTensor()(img).unsqueeze(0)
 	# preprocess, (-1, 1)
  img = -1 + 2 * img
  if gpu > -1:
    with torch.no_grad():
        img = img.cuda()
  else:
    img = Variable(img, volatile=True).float()
 
  output_image = model(img)
  output_image = output_image[0]
	# BGR -> RGB
  output_image = output_image[[2, 1, 0], :, :]
	# deprocess, (0, 1)
  output_image = output_image.data.cpu().float() * 0.5 + 0.5
  
	# save
  output_image =transforms.ToPILImage()(output_image)
  return output_image



print('Type 0 for using webcam, type 1 for using videofile')
method = int(input())
if method == 1:
    print('Type the name of the video file:')
    name = input()
else:
    name = 'MyOutputVid.avi'

print('Type 0 for applying cartoonizer to face only, type 1 for converting the whole area')
area = int(input())
fps = 24
if method == 0:
    #Recording the face part
    camera = cv2.VideoCapture(0)
    size = (int(camera.get(cv2.CAP_PROP_FRAME_WIDTH)),
            int(camera.get(cv2.CAP_PROP_FRAME_HEIGHT)))
    videoWriter = cv2.VideoWriter(
        'MyOutputVid.avi', cv2.VideoWriter_fourcc('M','J','P','G'), fps, size)
    print('Starting record')
    while (cv2.waitKey(1) == -1):
        success, frame = camera.read()
        if success:
            cv2.imshow('Record', frame)
            videoWriter.write(frame)
    camera.release()
    cv2.destroyAllWindows()




print('Processing...')
vid = cv2.VideoCapture(name)
flag = 1
size = (int(vid.get(cv2.CAP_PROP_FRAME_WIDTH)),
        int(vid.get(cv2.CAP_PROP_FRAME_HEIGHT)))
videoWriter = cv2.VideoWriter(
    'Result.avi', cv2.VideoWriter_fourcc('M','J','P','G'), fps, size)
    
while(flag):
    success, pic = vid.read()
    if success:
        if area == 0:
            gray = cv2.cvtColor(pic, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.3, 5, minSize=(20, 20))#check for faces on image
            flag1 = 0
            for (x, y, w, h) in faces:
                test = pic[y:y+h, x:x+w]
                test = cv2.cvtColor(test, cv2.COLOR_BGR2RGB)
                out_img = np.array(test_GAN(test))
                out_img = cv2.cvtColor(out_img, cv2.COLOR_BGR2RGB)
                rows = len(out_img)
                columns =len(out_img[0])
                a = rows - h
                b = columns - w
                pic[y:y+h+a, x:x+w+b] = out_img
                torch.cuda.empty_cache()
                flag1 = 1
        else:
            pic = cv2.cvtColor(pic, cv2.COLOR_BGR2RGB)
            out_img = np.array(test_GAN(pic))
            out_img = cv2.cvtColor(out_img, cv2.COLOR_BGR2RGB)
            torch.cuda.empty_cache()
    else:
        flag = 0
    if area == 0:
        videoWriter.write(pic)
    else:
        videoWriter.write(out_img)
vid.release
print('Finished')
