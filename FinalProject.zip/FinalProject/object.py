#ROBT310: Project - Cartoonization of Image Parts
#Object detection and cartoonization
#Aibek Abilgazym, ID:201895901
#Karina Burunchina, ID:201545437
#Zarema Balgabekova, ID:201783270

import numpy as np
import cv2

def color_quantization(img, k):
# Defining input data for clustering
  data = np.float32(img).reshape((-1, 3))
# Defining criteria
  criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1.0)
# Applying cv2.kmeans function
  ret, label, center = cv2.kmeans(data, k, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
  center = np.uint8(center)
  result = center[label.flatten()]
  result = result.reshape(img.shape)
  return result


def filter_cartoonization(img):

  edges = cv2.Canny(img,100,200)
  ret,th2 = cv2.threshold(edges,100,255,cv2.THRESH_BINARY_INV)


  color = cv2.bilateralFilter(img, d=9, sigmaColor=200,sigmaSpace=200)

  cartoon = cv2.bitwise_and(color, color, mask=th2)


  img_1 = color_quantization(cartoon, 12)
#  img_1 = cv2.cvtColor(img_1, cv2.COLOR_BGR2RGB)
  return img_1


def Object_extr (test_img, canny_low = 60, canny_high = 180, min_area = 0.005, max_area = 0.8, dilate_iter = 10, erode_iter = 10): 
  
  if test_img.shape[1] > 600:
    scale_percent = 70 # percent of original size
    width = int(test_img.shape[1] * scale_percent / 100)
    height = int(test_img.shape[0] * scale_percent / 100)
    dim = (width, height)
    # resize image
    test_img = cv2.resize(test_img, dim)
  
  
  
  # Convert image to grayscale        
  image_gray = cv2.cvtColor(test_img, cv2.COLOR_BGR2GRAY)
  # Apply Canny Edge Dection
  edges = cv2.Canny(image_gray, canny_low, canny_high)
  #dilating and eroding performs a closing operation to fill narrow gaps and notches
  edges = cv2.dilate(edges, None)
  edges = cv2.erode(edges, None)

  # get the contours and their areas
  #the OpenCV function findContours returns an array of information. Of this information, we only care about the the contours, which are indexed at 1.
  #For all the contours found, a tuple of the actual contour itself and its area are stored in a list.
  contour_info = [(c, cv2.contourArea(c),) for c in cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)[0]]
  # Get the area of the image as a comparison
  image_area = image_gray.shape[0] * image_gray.shape[1]  
      
  # calculate max and min areas in terms of pixels
  max_area = max_area * image_area
  min_area = min_area * image_area

  # Set up mask with a matrix of 0's
  mask = np.zeros(test_img.shape[:2], dtype = np.uint8)

  # Go through and find relevant contours and apply to mask
  for contour in contour_info:
    # Instead of worrying about all the smaller contours, if the area is smaller than the min, the loop will break
    if contour[1] > min_area and contour[1] < max_area:
      # Add contour to mask
      mask = cv2.fillConvexPoly(mask, contour[0], (255))

  # use dilate, erode
  mask = cv2.dilate(mask, None, iterations=dilate_iter)
  mask = cv2.erode(mask, None, iterations=erode_iter)
     
  filtered = filter_cartoonization(test_img)
  # Blend the image and the mask
  not_mask = cv2.bitwise_not(mask)
  Masked_img = cv2.bitwise_and(test_img,test_img,mask = not_mask)
  Masked_back_gan = cv2.bitwise_and(filtered, filtered, mask = mask)

  result = cv2.bitwise_or(Masked_img, Masked_back_gan)
  #result = cv2.cvtColor(result, cv2.COLOR_BGR2RGB)
  cv2.imwrite('kek.jpg',result)
  return result
  

test_img = cv2.imread('flower2.jpg')
#test_img = cv2.cvtColor(test_img, cv2.COLOR_BGR2RGB)
result = Object_extr(test_img)